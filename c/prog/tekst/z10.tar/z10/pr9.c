#include <stdio.h>


int main()
{
char t[]="ala ma kota";
t[11]='r';
printf("%s",t);
return 0;
}

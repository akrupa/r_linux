#include <stdio.h>


int main()
{
char a[100];
int i=33;
sprintf(a,"%d",i);
printf("%s",a);
return 0;
}

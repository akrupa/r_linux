#include <stdio.h>


int main()
{
char *t="ala ma kota";
char *w=t;
w[3]=67;
printf("%s",w);
return 0;
}

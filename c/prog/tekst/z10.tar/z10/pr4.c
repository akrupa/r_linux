#include <stdio.h>


int main()
{
char *t="ala ma kota";
char w[]="a kot ma ale";
char p[]={'a','l','a',' ','m','a',' ','k','o','t','a'};
printf("%s",t);
printf(t);
printf("%s",w);
printf("%s",p);
return 0;
}

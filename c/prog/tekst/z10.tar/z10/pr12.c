#include <stdio.h>
#include <strings.h>


int main()
{
char *a="ala";
char *b="ala";
if (a==b) printf("rowne"); else printf("rozne");
return 0;
}

#include <stdio.h>


int main()
{
char t[]="ala ma kota";
t[3]=0;
printf("%s",t);
return 0;
}

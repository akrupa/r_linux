#include <stdio.h>


int main()
{
char *t="ala ma kota";
char w[]="a kot ma ale";
t="ala ma kota a kot ma ale";
printf("%s",t);
printf("%s",w);
return 0;
}

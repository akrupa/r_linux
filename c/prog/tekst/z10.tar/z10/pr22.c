#include <stdio.h>
#include <strings.h>


int main()
{
char a[100]="10";
int i=atoi(a);
printf("%d",i);
return 0;
}
